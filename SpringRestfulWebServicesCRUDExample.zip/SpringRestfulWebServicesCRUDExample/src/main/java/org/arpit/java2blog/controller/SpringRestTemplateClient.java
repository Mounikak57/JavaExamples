package org.arpit.java2blog.controller;

import java.util.List;
import org.arpit.java2blog.bean.Country;
import org.arpit.java2blog.service.CountryService;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class SpringRestTemplateClient {
	public static final String REST_BASE_URI = "http://localhost:8082/SpringRestfulWebServicesCRUDExample";
	CountryService countryService = new CountryService();
	static RestTemplate restTemplate = new RestTemplate();
	List<Country> listOfCountries = countryService.getAllCountries();

	/** POST **/
	public static void createCountry() {
		Country country = new Country();
		country.setCountryName("France");
		country.setPopulation(90000);

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		// headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));

		HttpEntity entity = new HttpEntity<>(country, headers);
		restTemplate.postForObject(REST_BASE_URI + "/countries", entity, Country.class);
	}

	/** GET **/
	private static void getCountryById(int id) {
		Country country = restTemplate.getForObject(REST_BASE_URI + "/country/" + id, Country.class);
		System.out.println("**** CountryById : " + id + "****");
		System.out.println("Id :" + country.getId() + "    CountryName : " + country.getCountryName()
				+ "   Population : " + country.getPopulation());
	}

	public static void main(String args[]) {
		createCountry();
		getCountryById(4);
	}
}