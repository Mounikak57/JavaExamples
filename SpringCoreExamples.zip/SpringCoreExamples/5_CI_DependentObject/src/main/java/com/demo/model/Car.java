package com.demo.model;

public class Car {
	private String carName;
	private Engine engine;

	public Car(String carName, Engine engine) {
		this.carName = carName;
		this.engine = engine;
	}

	public void printCarData() {
		System.out.println(carName + " " + engine.toString());

	}
}
