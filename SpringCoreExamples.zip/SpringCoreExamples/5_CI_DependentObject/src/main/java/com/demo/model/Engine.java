package com.demo.model;

public class Engine {
	private String engineName;

	public Engine(String engineName) {
		this.engineName = engineName;
	}

	public String toString() {
		return engineName;
	}
}
