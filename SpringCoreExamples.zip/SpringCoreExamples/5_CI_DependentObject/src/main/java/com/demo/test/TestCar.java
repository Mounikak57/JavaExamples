package com.demo.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.Car;

public class TestCar {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("car.xml");
		Car c1 = (Car) applicationContext.getBean("c1");
		c1.printCarData();
		Car c2 = (Car) applicationContext.getBean("c2");
		c2.printCarData();

	}
}
