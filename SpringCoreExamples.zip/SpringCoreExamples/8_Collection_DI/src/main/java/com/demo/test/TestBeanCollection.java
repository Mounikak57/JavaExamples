package com.demo.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.BeanCollection;

public class TestBeanCollection {
	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("beanCollection.xml");
		BeanCollection bean = (BeanCollection) ac.getBean("collection");
		bean.printData();

	}
}
