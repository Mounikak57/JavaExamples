package com.demo.model;

public class Car {
	private int num;
	private String carName;

	public Car(int num, String carName) {
		this.num = num;
		this.carName = carName;
	}

	public void printCarData() {
		System.out.println(num + " " + carName);

	}
}
