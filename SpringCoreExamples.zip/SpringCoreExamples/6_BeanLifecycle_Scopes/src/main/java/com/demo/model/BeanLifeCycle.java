package com.demo.model;

public class BeanLifeCycle {
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public void myInit(){
	      System.out.println("Bean is going through init.");
	   }
	   public void myDestroy() {
	      System.out.println("Bean will destroy now.");
	   }

}
