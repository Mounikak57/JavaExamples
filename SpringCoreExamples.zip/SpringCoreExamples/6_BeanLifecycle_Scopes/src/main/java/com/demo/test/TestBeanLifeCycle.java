package com.demo.test;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.BeanLifeCycle;

public class TestBeanLifeCycle {
public static void main(String[] args) {
	AbstractApplicationContext  context =new ClassPathXmlApplicationContext("beansLifecycle.xml");
	 BeanLifeCycle bean = (BeanLifeCycle) context.getBean("helloWorld");
	 bean.getMessage();
     context.registerShutdownHook();
}
}
