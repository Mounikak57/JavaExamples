package com.demo.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.BeanScope;

public class TestBeanScope {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beanScopes.xml");
		BeanScope bean1 = (BeanScope) context.getBean("helloWorld");
		bean1.setMessage("I'm object A");
		bean1.getMessage();
		BeanScope bean2 = (BeanScope) context.getBean("helloWorld");
		bean2.getMessage();
	}
}
