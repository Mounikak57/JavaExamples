package com.demo.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.Employee;

public class TestEmployee {
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("employee.xml");
		Employee employee = (Employee) applicationContext.getBean("emp");
		employee.display();
	}
}
