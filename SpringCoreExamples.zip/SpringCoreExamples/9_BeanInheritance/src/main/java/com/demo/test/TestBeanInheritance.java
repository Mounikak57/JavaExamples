package com.demo.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.Test;
import com.demo.model.Test1;

public class TestBeanInheritance {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("beanInheritance.xml");
		//ApplicationContext context = new ClassPathXmlApplicationContext("beanInheritanceTemplate.xml");
		//Test1 test1 = (Test1) context.getBean("beanTeamplate");
		Test1 test1 = (Test1) context.getBean("test1");
		test1.getMessage1();
		test1.getMessage2();
		Test test = (Test) context.getBean("test");
		test.getMessage1();
		test.getMessage2();
		test.getMessage3();
	}
}
