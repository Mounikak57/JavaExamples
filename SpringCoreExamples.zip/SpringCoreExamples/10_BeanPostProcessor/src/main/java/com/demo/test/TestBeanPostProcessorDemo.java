package com.demo.test;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.BeanPostProcessorDemo;

public class TestBeanPostProcessorDemo {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("beanPostProcessor.xml");
		BeanPostProcessorDemo obj = (BeanPostProcessorDemo) context.getBean("bpr");
		obj.getMessage();
		context.registerShutdownHook();// for graceful shutdown and calls the relevant destroy methods
	}
}
