package com.demo.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.demo.model.Car;

public class TestInnerBean {
	public static void main(String[] args) {
		ApplicationContext ap = new ClassPathXmlApplicationContext("innerBeans.xml");
		Car car = (Car) ap.getBean("c");
		car.printCarData();
	}
}
