package com.fileoperations.demo;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class PrintWriterDemo {
	public static void main(String[] args) throws FileNotFoundException {
		PrintWriter printWriter = new PrintWriter("D:\\Properties\\FileDemo.txt");
		printWriter.write(100);// gives value
		printWriter.println(100);// print 100
		printWriter.println("Hello World");
		printWriter.flush();
		printWriter.close();
		System.out.println("Success");
	}
}
