package com.fileoperations.demo;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedWriterDemo {
	public static void main(String[] args) throws IOException {
		FileWriter writer = new FileWriter("D:\\Properties\\FileDemo.txt");
		BufferedWriter bufferedWriter = new BufferedWriter(writer);
		bufferedWriter.write("Welcome to File Operations");
		 bufferedWriter.newLine();
		 bufferedWriter.write(100);
		 bufferedWriter.newLine();
		char[] ch = { 'R', 'a', 'm', 'u' };
		bufferedWriter.write(ch);
		bufferedWriter.flush();
		bufferedWriter.close();
		System.out.println("Success");
	}
}
