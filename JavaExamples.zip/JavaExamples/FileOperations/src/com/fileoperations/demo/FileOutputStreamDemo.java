package com.fileoperations.demo;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

public class FileOutputStreamDemo {
	public static void main(String[] args) {
		try {
			FileOutputStream fout = new FileOutputStream("D:\\Properties\\FileOutputDemo.txt");
			String lineSeparator = System.getProperty("line.separator");
			BufferedOutputStream bout=new BufferedOutputStream(fout);    
			fout.write(65);
			fout.write(lineSeparator.getBytes());
			String s = "Welcome to I/o Operations";
			byte b[] = s.getBytes();// converting string into byte array
			fout.write(b);
			fout.write(lineSeparator.getBytes());
			fout.write(97);
			fout.flush();
			fout.close();
			System.out.println("success...");
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
