package com.fileoperations.demo;

import java.io.Externalizable;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;

public class ExternalizableDemo implements Externalizable {
	String s;
	int i;
	public ExternalizableDemo() {
		System.out.println("public no-arg constructor");
	}

	public ExternalizableDemo(String s, int i) {
		this.s = s;
		this.i = i;
	}

	public void writeExternal(ObjectOutput out) throws IOException {
		out.writeObject(s);
		out.writeInt(i);
	}

	public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
		s = (String) in.readObject();
		i = in.readInt();
	}

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		ExternalizableDemo externalizableDemo = new ExternalizableDemo("Anu",100);
		// serialization
		FileOutputStream fos = new FileOutputStream("D:\\Properties\\ExternalDemo.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(externalizableDemo);
		// de-serialization
		FileInputStream fis = new FileInputStream("D:\\Properties\\ExternalDemo.txt");
		ObjectInputStream ois = new ObjectInputStream(fis);
		ExternalizableDemo output = (ExternalizableDemo) ois.readObject();
		System.out.println(output.s+output.i);
		fos.close();
		System.out.println("success...");
	}
}
