package com.fileoperations.demo;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class TransientKeywordDemo implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Normal variables
	int i = 10, j = 20;
	String s="Anu";
	// Transient variables
	transient int k = 30;
	// Use of transient has no impact here
	transient static int l = 40;
	transient final int m = 50;

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		TransientKeywordDemo input = new TransientKeywordDemo();
		// serialization
		FileOutputStream fos = new FileOutputStream("D:\\Properties\\TransientDemo.txt");
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(input);
		 // de-serialization 
        FileInputStream fis = new FileInputStream("D:\\Properties\\TransientDemo.txt"); 
        ObjectInputStream ois = new ObjectInputStream(fis); 
        TransientKeywordDemo output = (TransientKeywordDemo)ois.readObject(); 
        System.out.println("i = " + output.i); 
        System.out.println("j = " + output.j); 
        System.out.println("k = " + output.k); 
        System.out.println("l = " + output.l);   
        System.out.println("m = " + output.m); 
        System.out.println("s = " + output.s); 
        fos.close();
		System.out.println("success...");
        
	}
}
