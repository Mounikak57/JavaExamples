package com.exception.demo;

public class FinallyBlockDemo {
	public static void main(String args[]) {
		try {
			int data = 20 / 4;
			System.out.println(data);
			//System.exit(0);
		}
		catch (NullPointerException e) {
			System.out.println(e);
		} finally {
			System.out.println("finally block is always executed");
		}
		System.out.println("rest of the code...");
	}
}
