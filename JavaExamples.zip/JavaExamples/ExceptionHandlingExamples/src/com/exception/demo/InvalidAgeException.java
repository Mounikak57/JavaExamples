package com.exception.demo;

public class InvalidAgeException extends Exception {
	InvalidAgeException(String s) {
		super(s);//for getting immediate super class constructor
	}
}
