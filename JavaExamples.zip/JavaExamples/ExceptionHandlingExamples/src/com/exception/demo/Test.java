package com.exception.demo;

public class Test {
	// handle by using throws at main also
	public static void main(String[] args) {
		try {
			Thread.sleep(500);
			System.out.println("throws demo");

		} catch (InterruptedException e) { // TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
