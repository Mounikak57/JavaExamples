package com.exception.demo;

public class ExceptionInitializerDemo {
public static void main(String[] args) {
//	m1();
	Thread t=new Thread();
	t.setPriority(100);//IllegalArguement Exception
}

	/*
	 * public static void m1() { m2(); } public static void m2() { m1(); }
	 */
	/*
	 * static { String s=null; System.out.println(s.toString()); }
	 */
}
