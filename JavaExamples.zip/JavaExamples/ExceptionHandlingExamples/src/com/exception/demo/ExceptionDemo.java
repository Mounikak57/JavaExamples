package com.exception.demo;

public class ExceptionDemo {
	public static void main(String args[]) {
		try {
			// code which may raise exception
			//int i = 100 / 0;// ArithmeticException
			 //String s=null;
			// System.out.println(s.length());//NullPointerException
			// String s1="abc";
			// int j=Integer.parseInt(s1);//NumberFormatException
			//int a[] = new int[5];
			// a[10] = 50;//ArrayIndexOutOfBoundsException
			//String str = "Java Exception Demo!";
			// System.out.println("Length: " + str.length());

			// The following statement throws an exception, because
			// the request index is invalid.
			// char ch = str.charAt(50);
			 Object obj=new String("Sri");
			 StringBuffer sb=(StringBuffer)obj;//classcastException

		} /*
			 * catch (ArithmeticException e) { System.out.println("Message:" +
			 * e.getMessage()); System.out.println(e); }
			 */

		catch (Exception e) {
			
			System.out.println(e);;
		}

		// rest code of the program
		System.out.println("rest of the code...");
	}
}
