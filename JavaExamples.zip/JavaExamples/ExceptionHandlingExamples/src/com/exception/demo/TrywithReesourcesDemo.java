package com.exception.demo;

import java.io.FileOutputStream;

public class TrywithReesourcesDemo {
	public static void main(String args[]) {
		// Using try-with-resources
		try (FileOutputStream fileOutputStream = new FileOutputStream("D:\\Properties\\info.properties")) {
			String msg = "Welcome Rajitha!";
			byte byteArray[] = msg.getBytes(); // converting string into byte array
			fileOutputStream.write(byteArray);
			System.out.println("Message written to file successfuly!");
		} catch (Exception exception) {
			System.out.println(exception);
		}
	}
}
