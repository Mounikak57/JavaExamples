package com.exception.demo;

import java.io.IOException;

public class ThrowsDemo {
	void m1() throws IOException {
		System.out.println("method operation performed");
	}

	public static void main(String[] args) throws IOException {
		ThrowsDemo demo=new ThrowsDemo();
		try {
		demo.m1();
		System.out.println("normal flow");
	}
		catch (IOException e) {
			System.out.println(e);
	}
	}
}
