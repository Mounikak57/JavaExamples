package com.string.demo;

public final class ImmutableDemo {
	final String pancardNumber;

	public ImmutableDemo(String pancardNumber) {
		this.pancardNumber = pancardNumber;
	}

	public String getPancardNumber() {
		return pancardNumber;
	}

}
