package com.string.demo;

public class TrimDemo {
public static void main(String[] args) {
	 String s1 ="  hello world program   ";  
     System.out.println(s1.length());  
     System.out.println(s1); //Without trim()  
     String str = s1.trim();  
     System.out.println(str.length());  
     System.out.println(str); //With trim()
     System.out.println(s1.trim()+"java");//with trim()
     //value Of converts different types to String
     // char to String         
     char ch1 = 'A';    
     char ch2 = 'B';  
     String str1 = String.valueOf(ch1);    
     String str2 = String.valueOf(ch2);  
     System.out.println(str1);  
     System.out.println(str2);
}
}
