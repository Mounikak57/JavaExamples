package com.string.demo;

public class EqualsDemo {
public static void main(String[] args) {
	String s1="Goodmorning";  
	String s2="goodmorning";  
	String s3="GOODMORNING";  
	String s4="world";  
	System.out.println(s1.equals(s2));//true because content and case is same  
	System.out.println(s1.equals(s3));//false because case is not same  
	System.out.println(s1.equals(s4));//false because content is not same  
	System.out.println(s1.equalsIgnoreCase(s2));//true because content and case both are same  
	System.out.println(s1.equalsIgnoreCase(s3));//true because case is ignored  
	System.out.println(s1.equalsIgnoreCase(s4));//false because content is not same
}
}
