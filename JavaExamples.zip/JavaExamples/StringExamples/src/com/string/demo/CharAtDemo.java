package com.string.demo;

public class CharAtDemo {
	public static void main(String args[]){  
		String name="RamaKrishna";  
		char ch=name.charAt(5);//returns the char value at the 5th index  
		System.out.println(ch);
		//char ch1=name.charAt(40);
		//System.out.println(ch1);//StringIndexOutOfBoundsException
		System.out.println("");
		//Acceessing first and last characters from String
		 int strLength = name.length(); 
		 System.out.println("length of String:"+strLength);
		// Fetching first character  
		    System.out.println("Character at 0 index is: "+ name.charAt(0));      
		    // The last Character is present at the string length-1 index  
		    System.out.println("Character at last index is: "+ name.charAt(strLength-1)); 
		    System.out.println("");
		    //Accessing all the elements present at odd index
		    for (int i=0; i<=name.length()-1; i++) {  
	            if(i%2!=0) {  
	                System.out.println("Char at "+i+" place "+name.charAt(i));  
	            }  
	        }
		}
}
