package com.string.demo;

public class SplitDemo {
public static void main(String[] args) {
	String s1="My Hello World Example";  
	//startswith method
	System.out.println(s1.startsWith("My"));  
	System.out.println("startsWith:"+s1.startsWith("My Hello"));
	String[] words=s1.split("\\s");//splits the string based on whitespace  
	//using java foreach loop to print elements of string array  
	for(String w:words){  
	System.out.println(w);  
	}  
}
}
