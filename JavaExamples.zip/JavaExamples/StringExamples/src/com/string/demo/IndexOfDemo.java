package com.string.demo;

public class IndexOfDemo {
	public static void main(String[] args) {
		String s = "index of demo";
		// index of first occurance of specified character
		int index1 = s.indexOf('d');
		System.out.println("index1:" + index1);
		// last occcurance of specified character
		int index2 = s.lastIndexOf('e');// returns last index of 's' char value
		System.out.println("index2:" + index2);
		int index3 = s.lastIndexOf('d', 5);// from index 5
		System.out.println("index3:" + index3);
	}
}
