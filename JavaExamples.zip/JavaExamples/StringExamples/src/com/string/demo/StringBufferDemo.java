package com.string.demo;

public class StringBufferDemo {
public static void main(String[] args) {
	StringBuffer sb=new StringBuffer("Hello ");
	sb.append("world");//now original string is changed  
	System.out.println(sb);
	sb.insert(1,"hi");//now original string is changed  first place value will insert
	sb.replace(1,3,"hi");  
	System.out.println("replace:"+sb);
	sb.delete(1,3);  
	System.out.println(sb);
	sb.reverse();
	System.out.println(sb);
	sb.append("black is my fav colour");  
	System.out.println(sb.capacity());//now (16*2)+2=34 i.e (oldcapacity*2)+2
}
}
