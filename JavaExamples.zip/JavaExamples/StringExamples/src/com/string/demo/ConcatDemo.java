package com.string.demo;

public class ConcatDemo {
public static void main(String[] args) {
	String str1 = "Hello";  
    String str2 = "World";  
    String str3 = "Hi";  
    // Concatenating Space among strings  
    String str4 = str1.concat(" ").concat(str2).concat(" ").concat(str3);  
    System.out.println(str4);         
    // Concatenating Special Chars        
    String str5 = str1.concat("!!!");  
    System.out.println(str5);         
    String str6 = str1.concat("@").concat(str2);  
    System.out.println(str6); 
    //contains meethod
    System.out.println("contains method output:"+str4.contains("World")); //true 
 // Case Sensitive  
    System.out.println(str4.contains("world")); // false 
    //endsWith method i.e with particular suffix or word
    System.out.println(str4.endsWith("i"));  
    System.out.println(str4.endsWith("Hi"));  
}
}
