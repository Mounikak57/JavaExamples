package com.string.demo;

public class ReplaceDemo {
public static void main(String[] args) {
	String s1="i am replace Demo i am example";  
	String replaceString=s1.replace("am","was");//replaces all occurrences of "is" to "was"
	System.out.println("replaceString"+replaceString);
	 String s2 = s1.replace("m","n"); // Replace 'm' with 'n'  
	System.out.println(s2);  
}
}
