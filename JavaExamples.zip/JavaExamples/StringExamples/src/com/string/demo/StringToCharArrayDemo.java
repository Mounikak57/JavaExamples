package com.string.demo;

public class StringToCharArrayDemo {
	public static void main(String[] args) {
		String s1 = "StringToCharArrayDemo";
		System.out.println("LowerCase:" + s1.toLowerCase());
		System.out.println("UpperCase:" + s1.toUpperCase());
		char[] ch = s1.toCharArray();
		int len = ch.length;
		System.out.println("Char Array length: " + len);
		System.out.println("Char Array elements: ");
		for (int i = 0; i < len; i++) {
			System.out.println(ch[i]);
		}
	}
}
