package com.hibernate.demo.HibernateSaveDemo.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.HibernateSaveDemo.model.Student;

public class StudentDao {
public static void main(String[] args) {
	// create container
			Configuration cfg = new Configuration();
			//cfg.configure("resources/hibernate.cfg.xml");
			// start container
			SessionFactory sf =
				    new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
			//SessionFactory sf = cfg.buildSessionFactory();// connections will create
			Student student = new Student();
			student.setId(456);
			student.setName("Rajitha b");
			student.setEmail("rajithacss1@gmail.com");
			Session session = sf.openSession();
			Transaction t = session.beginTransaction();
			session.save(student);
			t.commit();// for All DML we should commit insert,update,delete
			session.close();
			sf.close();// shutdown hibernate container
}
}
