package com.hibernate.demo.OneToOneDemo.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.OneToOneDemo.model.Vote;
import com.hibernate.demo.OneToOneDemo.model.Voter;

public class Client {
	public static void main(String[] args) {
		// create container
		Configuration cfg = new Configuration();
		// cfg.configure("resources/hibernate.cfg.xml");
		// start container
		SessionFactory sf = new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		// SessionFactory sf = cfg.buildSessionFactory();// connections will create
		Session session = sf.openSession();

		Voter v = new Voter();
		v.setVid(5);
		v.setVname("honeey");
		v.setVage(26);

		Vote vt1 = new Vote();
		vt1.setPname("Hyd");
		vt1.setCdate(new Date());
		vt1.setVoter(v);
		
		
		  Vote vt2=new Vote(); vt2.setPname("bdp"); vt2.setCdate(new Date());
		  vt2.setVoter(v);
		 

		session.save(v);
		session.save(vt1);
		//session.save(vt2);
		session.beginTransaction().commit();
		System.out.println("success");

	}
}
