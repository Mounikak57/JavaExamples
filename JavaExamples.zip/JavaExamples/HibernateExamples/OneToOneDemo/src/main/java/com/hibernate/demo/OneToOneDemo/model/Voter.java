package com.hibernate.demo.OneToOneDemo.model;

public class Voter {
	private int vid;
	private String vname;
	private int vage;
	public int getVid() {
		return vid;
	}
	public void setVid(int vid) {
		this.vid = vid;
	}
	public String getVname() {
		return vname;
	}
	public void setVname(String vname) {
		this.vname = vname;
	}
	public int getVage() {
		return vage;
	}
	public void setVage(int vage) {
		this.vage = vage;
	}
}
