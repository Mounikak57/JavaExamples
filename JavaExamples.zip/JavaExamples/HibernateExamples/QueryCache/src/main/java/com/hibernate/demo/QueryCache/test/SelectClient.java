package com.hibernate.demo.QueryCache.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.QueryCache.model.Employee;

import java.util.List;
import org.hibernate.Query;

public class SelectClient {
	public static void main(String[] args) {
		// create container
		Configuration cfg = new Configuration();
		// cfg.configure("resources/hibernate.cfg.xml");
		// start container
		SessionFactory sf = new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		// SessionFactory sf = cfg.buildSessionFactory();// connections will create
		Session session = sf.openSession();

		System.out.println("For first query...");
		Query q = session.createQuery("select e.name from  com.hibernate.demo.QueryCache.model.Employee e");
		q.setCacheable(true);

		List<String> list = q.list();
		for (String name : list) {
			System.out.println(name);
		}

		System.out.println("For second query...");
		Query q1 = session.createQuery("select e.name from  com.hibernate.demo.QueryCache.model.Employee e");
		q1.setCacheable(true);

		List<String> list1 = q1.list();
		for (String name : list1) {
			System.out.println(name);
		}
		System.out.println("for third query..");

		Query q2 = session.createQuery("select e.name from  com.hibernate.demo.QueryCache.model.Employee e");
		q2.setCacheable(true);

		List<String> list2 = q2.list();
		for (String name : list2) {
			System.out.println(name);
		}

		sf.close();

	}
}
