package com.hibernate.demo.ManyToOneDemo.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.ManyToOneDemo.model.Country;
import com.hibernate.demo.ManyToOneDemo.model.States;

public class Client {
	public static void main(String[] args) {
		// create container
		Configuration cfg = new Configuration();
		// cfg.configure("resources/hibernate.cfg.xml");
		// start container
		SessionFactory sf = new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		// SessionFactory sf = cfg.buildSessionFactory();// connections will create
		Session session = sf.openSession();
		Country c = new Country();
		c.setCid(3);
		c.setCountryname("UK");

		States s1 = new States();
		s1.setSid(9);
		s1.setStatename("de");
		s1.setCountry(c);

		States s2 = new States();
		s2.setSid(10);
		s2.setStatename("conncticut");
		s2.setCountry(c);

		session.save(s1);
		session.save(s2);
		session.save(c);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
		System.out.println("insertion success");
	}
}
