package com.hibernate.demo.OneToManyDemo.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.OneToManyDemo.model.Country;
import com.hibernate.demo.OneToManyDemo.model.States;

import org.hibernate.Transaction;

public class Client {
	public static void main(String[] args) {
		// create container
		Configuration cfg = new Configuration();
		// cfg.configure("resources/hibernate.cfg.xml");
		// start container
		SessionFactory sf = new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		// SessionFactory sf = cfg.buildSessionFactory();// connections will create
		Session session = sf.openSession();

		States s1 = new States();
		s1.setSid(6);
		s1.setStatename("TamilNadu");

		States s2 = new States();
		s2.setSid(7);
		s2.setStatename("Karnataka");

		Set<States> set = new HashSet<States>();
		set.add(s1);
		set.add(s2);

		Country c = new Country();
		c.setCid(8);
		c.setCountryname("India");
		c.setStates(set);

		// session.save(s1);
		// session.save(s2);
		session.save(c);
		Transaction transaction = session.beginTransaction();
		transaction.commit();
		System.out.println("success");
	}
}
