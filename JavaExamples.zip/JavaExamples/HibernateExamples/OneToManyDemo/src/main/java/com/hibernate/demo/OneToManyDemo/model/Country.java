package com.hibernate.demo.OneToManyDemo.model;

import java.util.Set;

public class Country {
	private int cid;
	private String countryname;
	private Set<States> states;

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCountryname() {
		return countryname;
	}

	public void setCountryname(String countryname) {
		this.countryname = countryname;
	}

	public Set<States> getStates() {
		return states;
	}

	public void setStates(Set<States> states) {
		this.states = states;
	}

}
