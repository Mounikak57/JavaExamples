package com.hibernate.demo.ManyToManyDemo.test;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.ManyToManyDemo.model.Course;
import com.hibernate.demo.ManyToManyDemo.model.Faculty;

public class Client {
	public static void main(String[] args) {
		// create container
		Configuration cfg = new Configuration();
		// cfg.configure("resources/hibernate.cfg.xml");
		// start container
		SessionFactory sf = new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		// SessionFactory sf = cfg.buildSessionFactory();// connections will create
		Session session = sf.openSession();
		Course c1 = new Course();
		c1.setCid(1);
		c1.setCname("scjp");
		c1.setFee(2000);

		Course c2 = new Course();
		c2.setCid(2);
		c2.setCname("struts");
		c2.setFee(1500);

		Course c3 = new Course();
		c3.setCid(3);
		c3.setCname("spring");
		c3.setFee(1500);

		Course c4 = new Course();
		c4.setCid(4);
		c4.setCname("Hibernate");
		c4.setFee(1500);

		Set<Course> cset = new HashSet<Course>();
		cset.add(c1);
		cset.add(c2);

		Set<Course> cset1 = new HashSet<Course>();
		cset1.add(c2);
		cset1.add(c3);
		cset1.add(c4);

		Faculty f1 = new Faculty();
		f1.setFid(6);
		f1.setFname("durga");
		f1.setYearex(10);
		f1.setCourses(cset);

		Faculty f2 = new Faculty();
		f2.setFid(7);
		f2.setFname("srikanth");
		f2.setYearex(5);
		f2.setCourses(cset);

		Faculty f3 = new Faculty();
		f3.setFid(8);
		f3.setFname("naveen");
		f3.setYearex(4);
		f3.setCourses(cset1);

		session.saveOrUpdate(f1);
		session.saveOrUpdate(f2);
		session.saveOrUpdate(f3);
		session.saveOrUpdate(c1);
		session.saveOrUpdate(c2);
		session.saveOrUpdate(c3);
		session.saveOrUpdate(c4);
		session.beginTransaction().commit();
		System.out.println("success");
		sf.close();
	}
}
