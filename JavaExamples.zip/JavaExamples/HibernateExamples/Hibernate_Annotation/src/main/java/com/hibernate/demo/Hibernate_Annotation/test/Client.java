package com.hibernate.demo.Hibernate_Annotation.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.demo.Hibernate_Annotation.model.Employee;

public class Client {
	public static void main(String[] args) {
		// create container
		Configuration cfg = new Configuration();
		// cfg.configure("resources/hibernate.cfg.xml");
		// start container
		SessionFactory sf = new Configuration().configure("resources/hibernate.cfg.xml").buildSessionFactory();
		// SessionFactory sf = cfg.buildSessionFactory();// connections will create
		Session session = sf.openSession();
		Transaction t = session.beginTransaction();

		Employee emp = new Employee();
		emp.setId(29);
		emp.setName("Sarada");
		emp.setEmail("saritha@gmail.com");
		session.save(emp);
		t.commit();
	}
}
