package com.collections.demo;

import java.util.TreeSet;

public class TreeSetDemoComparator {
	public static void main(String[] args) {
		// comparator Demo
		TreeSet<String> treeSet = new TreeSet<String>();
		treeSet.add("A");
		treeSet.add("ZL");
		treeSet.add("LAS");
		treeSet.add("BB");
		treeSet.add("AB");
		System.out.println("treeSet for comparator: " + treeSet);
		System.out.println("");
	}

}

