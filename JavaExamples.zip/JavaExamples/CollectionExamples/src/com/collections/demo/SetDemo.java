package com.collections.demo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class SetDemo {

	public static void main(String args[]) {
		// Creating HashSet and adding elements
		HashSet<String> set = new HashSet<String>();
		set.add("Ravi");
		set.add("Vijay");
		set.add("Ravi");
		set.add("Ajay");
		System.out.println("output of set" + set);
		System.out.println("");
		// Traversing elements
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		System.out.println("");
		// Hashset from another collection Object
		ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("one");
		arrayList.add("two");
		arrayList.add("three");
		HashSet<String> setObject = new HashSet<String>(arrayList);
		setObject.add("Gaurav");
		System.out.println("output of set from Collection obj" + setObject);
		System.out.println("");
		Iterator<String> i = setObject.iterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println("");
		// LinkedHashSet
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<String>();
		linkedHashSet.add("Honey");
		linkedHashSet.add("shiny");
		linkedHashSet.add("pinky");
		linkedHashSet.add("puppy");
		System.out.println("LinkedHashset output" + linkedHashSet);
		System.out.println("");
		Iterator<String> iterator1 = linkedHashSet.iterator();
		while (iterator1.hasNext()) {
			System.out.println(iterator1.next());
		}
	}
}
