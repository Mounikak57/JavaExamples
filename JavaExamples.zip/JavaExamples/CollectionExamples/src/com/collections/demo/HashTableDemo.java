package com.collections.demo;

import java.util.Hashtable;
import java.util.Map;

public class HashTableDemo {
	public static void main(String args[]) {
		//Hashtable<Integer, String> hashtable = new Hashtable<Integer, String>();
		Hashtable hashtable=new Hashtable();
		hashtable.put(100, "Ram");
		hashtable.put(102, "Ravi");
		hashtable.put(101, "Vijay");
		hashtable.put("ras", "Raju");
		System.out.println("Hashtable" + hashtable);
		System.out.println("");
		/*
		 * for (Map.Entry m : hashtable.entrySet()) { System.out.println(m.getKey() +
		 * " " + m.getValue()); }
		 */
		// Here, we specify the if and else statement as arguments of the method
		System.out.println("");
		System.out.println(hashtable.getOrDefault(101, "Not Found"));
		System.out.println("");
		System.out.println(hashtable.getOrDefault(105, "Not Found"));
	}
}
