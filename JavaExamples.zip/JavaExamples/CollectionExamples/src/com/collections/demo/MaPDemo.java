package com.collections.demo;

import java.util.*;

public class MaPDemo {
	public static void main(String[] args) {
		String s1 = "FB";
		String s2 = "EA";
		System.out.println(s1.hashCode());
		System.out.println(s1.hashCode());
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("aa", 1);
		map.put("bb", 2);
		map.put(s1, 3);
		map.put(s2, 4);
		map.put("cc", 5);
		map.put("cc", 6);
		System.out.println("Map:" + map);
	}
}
