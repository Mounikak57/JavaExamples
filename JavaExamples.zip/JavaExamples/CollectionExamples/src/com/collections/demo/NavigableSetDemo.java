package com.collections.demo;

import java.util.TreeSet;

public class NavigableSetDemo {
	public static void main(String[] args) {
		TreeSet<Integer> treeSet = new TreeSet<Integer>();
		treeSet.add(100);
		treeSet.add(200);
		treeSet.add(300);
		treeSet.add(400);
		treeSet.add(500);
		treeSet.add(600);
		treeSet.add(700);
		System.out.println("treeSet for NavigableSet: " + treeSet);
		System.out.println("");
		System.out.println("ceiling:" + treeSet.ceiling(400));// >=element
		System.out.println("");
		System.out.println("floor:" + treeSet.floor(300));// <=element
		System.out.println("");
		System.out.println("higher:" + treeSet.higher(400));// >e
		System.out.println("");
		System.out.println("lower:" + treeSet.lower(300));// <e
		System.out.println("");
		System.out.println("pollFirst:" + treeSet.pollFirst());// remove & returns first element
		System.out.println("");
		System.out.println("pollLast:" + treeSet.pollLast());// remove & returns last element
		System.out.println("");
		System.out.println("Descending Set:" + treeSet.descendingSet());// returns set in reverse order
		System.out.println("");
		System.out.println("output of treeSet" + treeSet);
	}
}
