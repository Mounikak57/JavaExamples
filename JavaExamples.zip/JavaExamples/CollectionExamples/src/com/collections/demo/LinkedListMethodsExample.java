package com.collections.demo;

import java.util.*;

public class LinkedListMethodsExample {
	public static void main(String[] args) {
		LinkedList<String> linkedList1 = new LinkedList<String>();
		// add method of LinkedList
		linkedList1.add("Ram");
		linkedList1.add("sitha");
		linkedList1.add("gouri");
		linkedList1.add("lakshman");
		linkedList1.add("gouri");
		System.out.println("add method output:" + linkedList1);
		System.out.println("");
		// add method baesd on index
		linkedList1.add(1, "Raja");
		System.out.println("add method based on index output:" + linkedList1);
		System.out.println("");
		// addAll method
		LinkedList<String> linkedList2 = new LinkedList<String>();
		linkedList2.add("Rajitha");
		linkedList2.add("Mounika");
		linkedList1.addAll(linkedList2);
		System.out.println("addAll method output:" + linkedList1);
		System.out.println("");
		// adding second list elements to first list at specific index
		linkedList1.addAll(2, linkedList2);
		System.out.println("addAll method based on index output:" + linkedList1);
		System.out.println("");
		// addFirst method of LinkedList
		linkedList1.addFirst("Abhi");
		System.out.println("addFirst method output:" + linkedList1);
		System.out.println("");
		// addLast method of LinkedList
		linkedList1.addLast("Mohan");
		System.out.println("addLast method output:" + linkedList1);
		System.out.println("");
		// removeFirst method of LinkedList
		linkedList1.removeFirst();
		System.out.println("removeFirst method output:" + linkedList1);
		System.out.println("");
		// removeLast method of LinkedList
		linkedList1.removeLast();
		System.out.println("removeLast method output:" + linkedList1);
		System.out.println("");
		// removeFirstOccurrence method of LinkedList
		linkedList1.removeFirstOccurrence("gouri");
		System.out.println("removeFirstOccurrence method output:" + linkedList1);
		System.out.println("");
		// removeLastOccurrence method of LinkedList
		linkedList1.removeLastOccurrence("gouri");
		System.out.println("removeLastOccurrence method output:" + linkedList1);
		System.out.println("");
		ListIterator<String> listIterator = linkedList1.listIterator();
		// get elements in forward direction
		System.out.println("get elements in forward direction");
		while (listIterator.hasNext()) {
			String s = (String) listIterator.next();
			System.out.println("index:" + listIterator.nextIndex() + " value:" + listIterator.next());
			// for replace operation
			if (s.equals("sitha"))
				listIterator.set("janaki");
		}
		System.out.println("output after remove and set operations" + listIterator);
		System.out.println("");
		// get elements in backward direction
		System.out.println("get elements in backward direction");
		while (listIterator.hasPrevious()) {

			System.out.println("index:" + listIterator.previousIndex() + " value:" + listIterator.previous());
		}
		System.out.println("");
		System.out.println("final output of linkedList" + linkedList1);
	}
}
