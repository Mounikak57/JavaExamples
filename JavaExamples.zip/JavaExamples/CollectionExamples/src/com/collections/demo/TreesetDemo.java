package com.collections.demo;

import java.util.Iterator;
import java.util.TreeSet;

public class TreesetDemo {

	public static void main(String args[]) {
		TreeSet<Integer> set = new TreeSet<Integer>();
		set.add(100);
		set.add(101);
		set.add(103);
		set.add(104);
		set.add(107);
		set.add(115);
		set.add(0);
		System.out.println("Intial Set: " + set);
		System.out.println("");
		System.out.println("Head Set: " + set.headSet(104));
		System.out.println("");
		System.out.println("SubSet: " + set.subSet(103, 110));
		System.out.println("");
		System.out.println("TailSet: " + set.tailSet(104));
		System.out.println("");
		// Creating and adding elements
		TreeSet<String> treeSet = new TreeSet<String>();
		treeSet.add("Ram");
		treeSet.add("sitha");
		treeSet.add("Abhi");
		treeSet.add("bindu");
		// by default follow ascending order
		System.out.println("print treeset for String type:" + treeSet);
		System.out.println("");
		System.out.println("Iterator in descending order");
		Iterator<String> i = treeSet.descendingIterator();
		while (i.hasNext()) {
			System.out.println(i.next());
		}
		System.out.println("");
		TreeSet<String> treeSet1 = new TreeSet<String>();
		treeSet1.add("A");
		treeSet1.add("C");
		treeSet1.add("B");
		treeSet1.add("D");
		treeSet1.add("E");
		System.out.println("Intial Set: " + treeSet1);
		System.out.println("");
		System.out.println("Head Set: " + treeSet1.headSet("C"));
		System.out.println("");
		System.out.println("SubSet: " + treeSet1.subSet("A", "E"));
		System.out.println("");
		System.out.println("TailSet: " + treeSet1.tailSet("C"));

	}
}
