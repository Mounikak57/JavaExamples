package com.collections.demo;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class TreeMapDemo {
	public static void main(String args[]) {
		Map map = new TreeMap();
		map.put(100, "Amit");
		map.put(102, "Ravi");
		map.put(101, "Vijay");
		map.put(103, "Ravi");
		// classcast Exception case
		// map.put("sri", "xxx");
		// map.put(null, "xxx");//NPE
		System.out.println("Map:" + map);
		System.out.println("");
		// get method
		System.out.println("get method:" + map.get(101).hashCode());
		System.out.println("");
		// containsKey
		System.out.println("containsKey:" + map.containsKey(103));
		System.out.println("");
		// containsValue
		System.out.println("containsValue:" + map.containsValue("Ravi"));
		System.out.println("");
		// putAll method
		Map<Integer, String> map1 = new HashMap<Integer, String>();
		map1.put(10, "Sritha");
		map1.put(30, "Geetha");
		map1.put(50, "Latha");
		map.putAll(map1);
		System.out.println("output of putAll method:" + map);
		System.out.println("");
		// keySet method ()
		Set<Integer> setObj = map.keySet();
		System.out.println("keySet() output is:" + map.keySet());
		System.out.println("");
		// Using entrySet() to get the set view
		System.out.println("The entrySet  is: " + map.entrySet());
		System.out.println("");
		// values method
		Collection<String> c = map.values();
		System.out.println("values method output:" + map.values());
		System.out.println("");
		// for (Entry<Integer, String> entry : map.entrySet())
		// System.out.println("Key = " + entry.getKey() + ", Value = " +
		// entry.getValue());
		// getting keys and values
		Iterator iterator = map.entrySet().iterator();
		while (iterator.hasNext()) {
			Map.Entry entry = (Map.Entry) iterator.next();
			// Integer key = (Integer)entry.getKey();
			// Integer value = (Integer)entry.getValue();
			System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue());
		}
		System.out.println("");
		// remove operation
		System.out.println("remove operation:" + map.remove(103));
	}
}
