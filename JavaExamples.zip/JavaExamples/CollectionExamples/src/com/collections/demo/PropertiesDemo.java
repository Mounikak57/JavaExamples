package com.collections.demo;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;

public class PropertiesDemo {
	public static void main(String[] args) throws IOException {
		Properties p = new Properties();
		String data = "test data";
		p.setProperty("name", "Sonoo Jaiswal");
		p.setProperty("email", "sonoojaiswal@javatpoint.com");
		// File file = new File("c://temp//testFile1.txt");
		// FileOutputStream out = new
		// FileOutputStream("D:\\Properties\\info.properties");
		p.store(new FileWriter("D:\\Properties\\info.properties"), "Javatpoint Properties Example");
		String email = p.getProperty("email");
		System.out.println("Email:" + email);

	}
}
