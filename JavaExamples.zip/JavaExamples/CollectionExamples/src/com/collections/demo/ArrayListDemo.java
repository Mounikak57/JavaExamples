package com.collections.demo;

import java.util.ArrayList;
import java.util.Collections;
//import java.util.Iterator;
import java.util.Iterator;

public class ArrayListDemo {
	public static void main(String[] args) {
		// Creating arraylist
		ArrayList<String> al1 = new ArrayList(1000);
		al1.add("Ram");
		al1.add("Geetha");
		al1.add("sam");
		al1.add("Ram");
		//al1.add(null);
		//al1.add(10);
		//al1.add(20);
		Collections.sort(al1);
		System.out.println(al1);
		System.out.println("sorting:" + al1);
		// Traversing list through Iterator
		Iterator itr = al1.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
