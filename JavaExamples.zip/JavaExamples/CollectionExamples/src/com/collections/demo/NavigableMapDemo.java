package com.collections.demo;

import java.util.TreeMap;

public class NavigableMapDemo {
	public static void main(String[] args) {
		TreeMap<String, String> map = new TreeMap<String, String>();
		map.put("b", "Banana");
		map.put("k", "Kiwi");
		map.put("a", "Apple");
		map.put("o", "Orange");
		map.put("c", "Cheeku");
		System.out.println("TreeMap for NavigableMap: " + map);
		System.out.println("");
		System.out.println("ceiling:" + map.ceilingKey("c"));// >=element
		System.out.println("");
		System.out.println("floor:" + map.floorKey("k"));// <=element
		System.out.println("");
		System.out.println("higher:" + map.higherKey("o"));// >e
		System.out.println("");
		System.out.println("lower:" + map.lowerKey("b"));// <e
		System.out.println("");
		System.out.println("pollFirst:" + map.pollFirstEntry());// remove & returns first element
		System.out.println("");
		System.out.println("pollLast:" + map.pollLastEntry());// remove & returns last element
		System.out.println("");
		System.out.println("Descending Map:" + map.descendingMap());// returns set in reverse order
		System.out.println("");
		System.out.println("output of Map" + map);
	}
}
