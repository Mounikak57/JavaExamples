package com.collections.demo;

import java.util.Stack;

public class StackDemo {
	public static void main(String[] args) {
		// Creating an empty Stack
		Stack<String> stack = new Stack<String>();
		// push() method to add elements
		stack.push("Welcome");
		stack.push("To");
		stack.push("Geeks");
		stack.push("For");
		stack.push("Geeks");
		// Displaying the Stack
		System.out.println("Initial Stack: " + stack);
		System.out.println();
		// peek() method for retrieve element at top of stack
		System.out.println("peek method output for stack:" + stack.peek());
		System.out.println();
		// Removing elements using pop() method
		System.out.println("Popped element: " + stack.pop());
		System.out.println();
		// Displaying the Stack after pop operation
		System.out.println("Stack after pop peration " + stack);
		System.out.println();
		// search operation of stack
		System.out.println(stack.search("To"));// returns offset value
		System.out.println();
		System.out.println(stack.search("z"));
	}

}
