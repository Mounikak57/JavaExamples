package com.collections.demo;

public class ComparableDemo {
	public static void main(String[] args) {
		System.out.println("A".compareTo("Z"));//obj2>obj1 -> +
		System.out.println("Z".compareTo("A"));//obj2<obj1->-
		System.out.println("A".compareTo("A"));//obj2= obj1->0
	}
}
