package com.collections.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class CollectionDemo {
	public static void main(String[] args) {
		// ArrayList
		List a1 = new ArrayList();
		a1.add("Rama");
		a1.add("sitha");
		a1.add(1);
		a1.add(1.25);
		a1.addAll(a1);
		a1.remove(a1);
		System.out.println("add all o/p"+a1.addAll(a1));
		System.out.println("remove o/p"+a1.addAll(a1));
		System.out.println();
		System.out.println(" ArrayList Elements");
		System.out.print("\t" + a1);

		// LinkedList
		List l1 = new LinkedList();
		l1.add("Rama");
		l1.add("sitha");
		l1.add(1);
		System.out.println();
		System.out.println(" LinkedList Elements");
		System.out.print("\t" + l1);

		// HashSet
		Set s1 = new HashSet();
		s1.add("Rama");
		s1.add("sitha");
		s1.add(1);
		a1.add(1.25);
		System.out.println();
		System.out.println(" Set Elements");
		System.out.print("\t" + s1);

		// HashMap
		Map<String, Integer> m1 = new HashMap<String, Integer>();
		m1.put("Zara", 8);
		m1.put("Mahnaz", 31);
		m1.put("Ayan", 12);
		m1.put("Daisy", 14);
		System.out.println();
		System.out.println(" Map Elements");
		System.out.print("\t" + m1);
		
		System.out.println("remove o/p"+a1.remove(a1));
		System.out.println(" o/p of a1"+a1);
		
		
	}

}
